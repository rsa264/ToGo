<?php
session_start();
header('Access-Control-Allow-Origin: *');  
require "connection.php";

//query
$sqll ="SELECT * FROM Request where status='ready'";
$rows=mysql_query($sqll,$conn);
$output=array();
if(mysql_num_rows($rows)!=0){
while ($data = mysql_fetch_assoc($rows)) {
$output[]=$data;
}
echo json_encode($output);
}
else    echo json_encode("empty");
mysql_close($database);
exit;
?>
<!--http://10.110.152.191/project1/www/signin.html-->

 

 